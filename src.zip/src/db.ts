import { Database } from "bun:sqlite"

const db = new Database("database.sqlite")

db.exec(`

    CREATE TABLE IF NOT EXISTS user (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        username            TEXT NOT NULL UNIQUE,
        password_hash           TEXT NOT NULL 
    );

     CREATE TABLE IF NOT EXISTS agenda (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL,
        titulo      TEXT NOT NULL,
        tipo        TEXT NOT NULL,
        disciplina  TEXT,
        data        TEXT NOT NULL,
        concluido   INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES user(id)
    );
`)



export { db }
export default db