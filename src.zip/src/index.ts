import login from "./index.html"
import db from "./db.ts"
import chat from "./chat.html"
import agenda from "./agenda.html"

const loggedUsers: any = {}
function usuarioLogado(req: any) {
    const ses = req.cookies.get("ses")
    if (!ses) return null
    return loggedUsers[ses] ?? null
}

const srv = Bun.serve({
    port: 3000,
    routes: {
        "/": login,




        "/user": {
            POST: async (req) => {
                const body = await req.json()
                const query = db.query(`INSERT INTO user(username, password_hash) VALUES(:username, :password_hash)`)
                const hash = await Bun.password.hash(body.password)
                const data = query.run({ ":username": body.username, ":password_hash": hash })
                return Response.json(data)
            },
        },

        "/login": {
            POST: async (req) => {
                const body = await req.json()
                const query = db.query(`SELECT * FROM user WHERE username=:username LIMIT 1`)
                const data: any = query.get({ ":username": body.username })
                if (!data)
                    return Response.json({ msg: "usuário não encontrado" }, { status: 404 })
                const isMatch = await Bun.password.verify(body.password, data.password_hash)
                if (!isMatch)
                    return Response.json({ msg: "senha não confere" }, { status: 401 })
                const uuid = crypto.randomUUID();
                delete data.password_hash
                loggedUsers[uuid] = data
                req.cookies.set("ses", uuid)
                return Response.json(isMatch)
            }
        },

        "/login/user": (req) => {
            const ses = req.cookies.get("ses")
            if (!ses || !loggedUsers[ses])
                return Response.json({ msg: "não permitido" }, { status: 401 })
            return Response.json(loggedUsers[ses])
        },

        "/chat": chat,

        "/agenda": agenda,

        "/logout": {
            POST: (req) => {
                const ses = req.cookies.get("ses")
                if (ses) delete loggedUsers[ses]
                req.cookies.delete("ses")
                return Response.json({ ok: true })
            }
        },

        "/api/agenda": {
            GET: (req) => {
                const usuario = usuarioLogado(req)
                if (!usuario)
                    return Response.json({ msg: "não permitido" }, { status: 401 })

                const query = db.query(`SELECT * FROM agenda WHERE user_id=:user_id ORDER BY concluido, data`)
                return Response.json(query.all({ ":user_id": usuario.id }))
            },

            POST: async (req) => {
                const usuario = usuarioLogado(req)
                if (!usuario)
                    return Response.json({ msg: "não permitido" }, { status: 401 })

                const body = await req.json()
                const titulo = String(body.titulo ?? "").trim().slice(0, 100)
                const disciplina = String(body.disciplina ?? "").trim().slice(0, 60)
                const tipo = body.tipo === "trabalho" ? "trabalho" : "prova"
                const data = String(body.data ?? "")

                if (!titulo || !/^\d{4}-\d{2}-\d{2}$/.test(data))
                    return Response.json({ msg: "Informe o título e a data" }, { status: 400 })

                const query = db.query(`INSERT INTO agenda(user_id, titulo, tipo, disciplina, data) VALUES(:user_id, :titulo, :tipo, :disciplina, :data)`)
                const info = query.run({
                    ":user_id": usuario.id,
                    ":titulo": titulo,
                    ":tipo": tipo,
                    ":disciplina": disciplina,
                    ":data": data
                })
                return Response.json({ id: info.lastInsertRowid })
            }
        },

        "/api/agenda/:id": {
            PATCH: async (req) => {
                const usuario = usuarioLogado(req)
                if (!usuario)
                    return Response.json({ msg: "não permitido" }, { status: 401 })

                const body = await req.json()
                const query = db.query(`UPDATE agenda SET concluido=:concluido WHERE id=:id AND user_id=:user_id`)
                const info = query.run({
                    ":concluido": body.concluido ? 1 : 0,
                    ":id": Number(req.params.id),
                    ":user_id": usuario.id
                })
                if (info.changes === 0)
                    return Response.json({ msg: "não encontrado" }, { status: 404 })
                return Response.json({ ok: true })
            },

            DELETE: (req) => {
                const usuario = usuarioLogado(req)
                if (!usuario)
                    return Response.json({ msg: "não permitido" }, { status: 401 })

                const query = db.query(`DELETE FROM agenda WHERE id=:id AND user_id=:user_id`)
                const info = query.run({
                    ":id": Number(req.params.id),
                    ":user_id": usuario.id
                })
                if (info.changes === 0)
                    return Response.json({ msg: "não encontrado" }, { status: 404 })
                return Response.json({ ok: true })
            }
        }
    },
})
